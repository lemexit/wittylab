<?php 
/**
 * Name: Functions.php 
 * Description: Control and extend script via this file. Note this file has no control over the admin panel!
 */