<?php
namespace Aws\DirectoryService;

use Aws\AwsClient;

/**
 * AWS Directory Service client
 */
class DirectoryServiceClient extends AwsClient {}
