<?php
namespace Aws\Redshift;

use Aws\AwsClient;

/**
 * This client is used to interact with the **Amazon Redshift** service.
 */
class RedshiftClient extends AwsClient {}
