<?php
namespace Aws\ElastiCache;

use Aws\AwsClient;

/**
 * This client is used to interact with the **Amazon ElastiCache** service.
 */
class ElastiCacheClient extends AwsClient {}
