<?php
namespace Aws\Swf;

use Aws\AwsClient;

/**
 * Amazon Simple Workflow Service (Amazon SWF) client.
 */
class SwfClient extends AwsClient {}
