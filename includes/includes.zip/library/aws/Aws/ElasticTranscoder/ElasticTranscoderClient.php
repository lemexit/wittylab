<?php
namespace Aws\ElasticTranscoder;

use Aws\AwsClient;

/**
 * This client is used to interact with the **Amazon Elastic Transcoder** service.
 */
class ElasticTranscoderClient extends AwsClient {}
