<?php
namespace Aws\Sns;

use Aws\AwsClient;

/**
 * This client is used to interact with the **Amazon Simple Notification Service (Amazon SNS)**.
 */
class SnsClient extends AwsClient {}
