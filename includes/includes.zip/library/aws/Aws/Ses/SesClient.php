<?php
namespace Aws\Ses;

/**
 * This client is used to interact with the **Amazon Simple Email Service (Amazon SES)**.
 */
class SesClient extends \Aws\AwsClient {}
