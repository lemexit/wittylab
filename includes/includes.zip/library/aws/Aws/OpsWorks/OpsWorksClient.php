<?php
namespace Aws\OpsWorks;

use Aws\AwsClient;

/**
 * This client is used to interact with the **AWS OpsWorks** service.
 */
class OpsWorksClient extends AwsClient {}
