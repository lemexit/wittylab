<?php
namespace Aws\Rds;

use Aws\AwsClient;

/**
 * This client is used to interact with the **Amazon Relational Database Service (Amazon RDS)**.
 */
class RdsClient extends AwsClient {}
